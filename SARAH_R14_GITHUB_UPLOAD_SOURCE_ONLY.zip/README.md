# SARAH AI Architect — M2 Offline Android APK Build Candidate

**Status: BUILD-ONLY, NOT authorized for installation, Android device testing or Minecraft connection.**

This is a new, deliberately disconnected native Android **Java** UI project, derived from the Android M01 build plan, *not* a deployed or qualified app. Gradle compiles via Android SDK 35 on GitHub Actions. No v0.1.1 APK has been built or Android-tested in this correction environment. Original Build #3 v0.1.0 APK identity does not identify a v0.1.1 build.

## Included

- Native six-screen interface: Overview, Architecture roadmap, Evidence status, Minecraft link (hard-coded **DISABLED**), Diagnostics, About / Test instructions.
- No Internet permission, no network stack/service, no Bluetooth, no AI, no world write, no copy of approval logic and no storage.
- App-only build pipeline with scoped host gates, SHA-256 provenance, APK signature and APK permission check.
- Frozen M01 GitHub repository transfer ZIP retained under `reference/` unchanged; its Local Link service is *not part of this APK*.

## How to submit to GitHub

1. Create a **private** repository named `sarah-ai-architect-android`, initialize with README, and share `https://github.com/<your-login>/sarah-ai-architect-android` with ChatGPT.
2. Upload the contents of **this package** at repository root. Do not upload this ZIP as a lone file if you want the workflow to run.
3. The workflow `.github/workflows/sarah-m2-offline-apk.yml` runs host checks and attempts real SDK compilation when pushed, or through Actions > Run workflow.
4. Retain APK, APK_SHA256, APK_SIGNATURE, PERMISSIONS, SOURCE_SHA256 and BUILD_PROVENANCE **for auditor**. Do not install or run it until an independent review grants permission for an exact build and test protocol.

## Deliberate nonclaims

There is **no installed v0.1.1 APK**, no proven Android launch, no live LLM or planner, no Bedrock bridge, no Minecraft accessibility and no construction. Java is retained for initial low-dependency Android compilation; Kotlin can follow through a separately reviewed change.

This M2 build does **not** alter R04 Owner Authority or L01.2 Local Link audit baselines. See `docs/M2_AUDITOR_BUILD_REQUEST.md`.

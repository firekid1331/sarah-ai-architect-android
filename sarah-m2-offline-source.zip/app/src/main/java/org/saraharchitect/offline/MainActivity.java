package org.saraharchitect.offline;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Offline-only UI; no permissions, world APIs, network or persistence. */
public final class MainActivity extends Activity {
    private TextView detail;
    private TextView heading;
    private LinearLayout root;

    private GradientDrawable surface(int color, int radiusDp) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(color);
        result.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density);
        return result;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }
    private void show(String title, String content) {
        heading.setText(title);
        detail.setText(content);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(30), dp(20), dp(28));
        root.setBackgroundColor(Color.rgb(16, 24, 34));
        scroll.addView(root);
        setContentView(scroll);

        TextView logo = text("SARAH", 34, Color.rgb(233, 247, 245));
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(logo);
        TextView sub = text("AI ARCHITECT  /  ANDROID M2", 12, Color.rgb(132, 199, 190));
        sub.setPadding(0,0,0,dp(20));
        root.addView(sub);
        TextView scope = text(OfflineContent.SAFETY, 12, Color.rgb(250, 213, 128));
        scope.setPadding(dp(13), dp(14), dp(13), dp(14));
        scope.setBackground(surface(Color.rgb(50, 49, 33), 12));
        root.addView(scope);

        String[] labels={"Overview", "Architecture", "Audit evidence", "Minecraft link"};
        String[] titles={"Dashboard", "Design studio", "Verification status", "Connection status"};
        String[] contents={OfflineContent.OVERVIEW, OfflineContent.ARCHITECTURE, OfflineContent.EVIDENCE, OfflineContent.CONNECTION};
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams navp = new LinearLayout.LayoutParams(-1,-2);
        navp.setMargins(0, dp(18), 0, dp(18));
        root.addView(nav, navp);
        for (int i=0;i<labels.length;i++) {
            final int selected=i;
            Button b = new Button(this);
            b.setText(labels[i]);
            b.setAllCaps(false);
            b.setOnClickListener(v->show(titles[selected], contents[selected]));
            nav.addView(b);
        }
        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16),dp(18),dp(16),dp(18));
        panel.setBackground(surface(Color.rgb(33,48,61),15));
        root.addView(panel);
        heading=text("Dashboard",23,Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        panel.addView(heading);
        detail=text(OfflineContent.OVERVIEW,15,Color.rgb(216,229,234));
        detail.setPadding(0,dp(12),0,0);
        panel.addView(detail);
        TextView footer=text(""+OfflineContent.RELEASE,11,Color.rgb(139,160,171));
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0,dp(24),0,0);
        root.addView(footer);
    }
}

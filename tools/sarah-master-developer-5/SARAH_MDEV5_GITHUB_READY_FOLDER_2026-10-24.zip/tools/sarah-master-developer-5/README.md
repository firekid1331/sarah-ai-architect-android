# SARAH Master Developer 5.0 — Engineering Workspace

Dedicated repository folder for **SARAH Master Developer 4.0 → 5.0 security supervisor and evidence verification**, **NOT Tool Forge**, the Android app, or the independent Auditor 5.0 workspace.

## Start here
- [STATUS.md](STATUS.md) — evidence status, historical gates and current milestone.
- [MILESTONES.md](MILESTONES.md) — completed candidate and upcoming milestones.
- [CHANGELOG.md](CHANGELOG.md) — release history.
- [UPDATE_PROTOCOL.md](UPDATE_PROTOCOL.md) — reproducibility and update standards.
- [milestones/R11V-R01](milestones/R11V-R01/) — bounded offline telemetry source, fixtures, tests, and documentation.

**Warning:** this is a *developer candidate*, not independent security qualification. All host operations, Android installation, Minecraft connectivity, autonomous construction, worker execution and production deployment remain unauthorized. The full original archive and historical vulnerability ledger are intentionally not copied into the public repository: preserve those frozen originals independently with their SHA-256 checksums. Never commit credentials, private keys, personal information or confidential evidence.

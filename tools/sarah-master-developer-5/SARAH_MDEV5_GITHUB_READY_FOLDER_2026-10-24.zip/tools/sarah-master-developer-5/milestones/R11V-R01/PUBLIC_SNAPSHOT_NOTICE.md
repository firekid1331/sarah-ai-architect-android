# Public GitHub snapshot notice

This directory is an intentionally **partial public source snapshot** of the 2026-10-24 R11V-R01 developer package. The complete frozen original (90,935 bytes) has SHA-256:

`a325bdee40801bbde1577bc63e3a115600863171a5ca97453c9c97f5f315efe3`

The full original includes additional historical obligation ledgers, archival reference ZIP, manifests and development evidence. Those files are **not** included here; this GitHub folder must not be represented as a full or independently reproducible replacement of the historical frozen package. The standalone offline telemetry source and tests are provided unchanged from the frozen R11V-R01 archive.

From `milestones/R11V-R01`:

```shell
python -m unittest discover -s tests -q
python -O -m unittest discover -s tests -q
python tools/run_mutation_checks.py
python tools/run_offline_analysis.py tests/synthetic_cgroup_text.json
```

Do **not** run `tools/validate_candidate.py` or `tools/rebuild_deterministic.py` from this partial public snapshot: those tooling scripts require the complete original evidence archive. For a full manifest/custody check, use the separate original package.

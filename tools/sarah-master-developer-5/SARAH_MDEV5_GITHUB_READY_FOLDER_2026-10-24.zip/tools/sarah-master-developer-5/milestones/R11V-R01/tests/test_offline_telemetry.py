"""Adversarial fixtures against the data-only R11V analyzer."""
import copy
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'source'))
from offline_telemetry import InvalidSyntheticInput, parse_bytes, analyze, _pressure, _kv, _scalar

PERCENT = 'some avg10=0.00 avg60=0.00 avg300=0.00 total=100\nfull avg10=0.00 avg60=0.00 avg300=0.00 total=20\n'
EVENTS = 'low 0\nhigh 0\nmax 0\noom 0\noom_kill 0\n'
CGROUP_BEFORE='populated 0\nfrozen 0\n'
CGROUP_AFTER='populated 0\nfrozen 0\n'

def sample():
    snapshot={'cgroup_identity_label':'mock-cgroup-11', 'memory.current':'1024\n',
              'memory.peak':'4096\n', 'memory.events': EVENTS,
              'memory.pressure': PERCENT,
              'cgroup.events':CGROUP_BEFORE,'pids.current':'0\n'}
    after=copy.deepcopy(snapshot)
    after['memory.current']='2048\n'
    after['memory.pressure']=PERCENT.replace('total=100','total=135').replace('total=20','total=25')
    after['memory.peak']='8192\n'
    after['cgroup.events']=CGROUP_AFTER
    return {'schema':'SARAH_R11V_SYNTHETIC_CGROUP_TEXT_V1',
            'provenance':'UNTRUSTED_SYNTHETIC',
            'claim':'DEVELOPER_DEMONSTRATION_ONLY','run_id':'synthetic-11',
            'observer_label':'not-a-protected-observer',
            'start_monotonic_ns':100000,'end_monotonic_ns':200000,
            'before':snapshot,'after':after}

def encode(payload):
    return json.dumps(payload,sort_keys=True,separators=(',',':')).encode()

class TestRawTelemetry(unittest.TestCase):
    def setUp(self): self.x=sample()
    def parse(self): return parse_bytes(encode(self.x))
    def reject(self):
        with self.assertRaises(InvalidSyntheticInput): self.parse()
    def test_baseline(self):
        out=self.parse()
        self.assertEqual(out['status'],'CONSISTENT_SYNTHETIC')
        self.assertEqual(out['qualification'],'NOT_QUALIFIED')
        self.assertFalse(out['kernel_containment_proven'])
        self.assertFalse(out['complete_descendant_cleanup_proven'])
        self.assertEqual(out['psi_stall_delta_microseconds_synthetic'],{'some':35,'full':5})
        self.assertEqual(out['memory_peak_measure'],'CGROUP_CHARGED_MEMORY_NOT_RSS')
    def test_never_claims_auditor_verdict(self):
        self.assertEqual(self.parse()['auditor_verdict'],'NOT_PERFORMED')
    def test_no_verified_peak_fd(self):
        self.assertIs(self.parse()['peak_reset_or_fd_provenance_verified'],False)
    def test_no_claim_even_when_empty(self):
        self.assertEqual(self.parse()['postcleanup_populated_untrusted'],0)
        self.assertEqual(self.parse()['qualification'],'NOT_QUALIFIED')
    def test_signed_provenance_forgery(self):
        self.x['provenance']='EXTERNAL_AUTHENTICATED';self.reject()
    def test_pretend_auditor_claim(self):
        self.x['claim']='AUDITOR_QUALIFIED';self.reject()
    def test_unknown_top_field(self):
        self.x['signature']='fake';self.reject()
    def test_missing_top_field(self):
        del self.x['observer_label'];self.reject()
    def test_missing_snapshot_field(self):
        del self.x['before']['memory.current'];self.reject()
    def test_unknown_snapshot_field(self):
        self.x['after']['memory.rss']='100';self.reject()
    def test_mixed_cgroup_identity(self):
        self.x['after']['cgroup_identity_label']='different';self.reject()
    def test_bad_run_id(self):
        self.x['run_id']='../unsafe';self.reject()
    def test_long_id(self):
        self.x['observer_label']='x'*129;self.reject()
    def test_zero_timestamp(self):
        self.x['start_monotonic_ns']=0;self.reject()
    def test_equal_timestamp(self):
        self.x['end_monotonic_ns']=self.x['start_monotonic_ns'];self.reject()
    def test_rollback_timestamp(self):
        self.x['end_monotonic_ns']=1;self.reject()
    def test_bool_timestamp(self):
        self.x['end_monotonic_ns']=True;self.reject()
    def test_float_timestamp(self):
        self.x['start_monotonic_ns']=3.2;self.reject()
    def test_negative_timestamp(self):
        self.x['start_monotonic_ns']=-1;self.reject()
    def test_huge_timestamp(self):
        self.x['end_monotonic_ns']=2**64;self.reject()
    def test_json_nan(self):
        raw=encode(self.x)[:-1]+b',"extra":NaN}'
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(raw)
    def test_json_infinity(self):
        raw=encode(self.x)[:-1]+b',"extra":Infinity}'
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(raw)
    def test_duplicate_json_key(self):
        raw=encode(self.x)[:-1]+b',"provenance":"EXTERNAL_AUTHENTICATED"}'
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(raw)
    def test_invalid_utf8(self):
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(b'\xff')
    def test_oversized_json(self):
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(b' '* (128*1024+1))
    def test_nonbytes(self):
        with self.assertRaises(InvalidSyntheticInput):parse_bytes('text')
    def test_deep_json(self):
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(('['*1000+'0'+']'*1000).encode())
    def test_boolean_scalar(self):
        self.x['before']['memory.current']=True;self.reject()
    def test_float_scalar(self):
        self.x['before']['memory.current']='4.5\n';self.reject()
    def test_negative_scalar(self):
        self.x['before']['memory.current']='-1\n';self.reject()
    def test_noncanonical_integer(self):
        self.x['before']['memory.current']='0001\n';self.reject()
    def test_scalar_overflow(self):
        self.x['before']['memory.current']=str(2**63)+'\n';self.reject()
    def test_scalar_doubleline(self):
        self.x['before']['memory.peak']='5\n6\n';self.reject()
    def test_null_metric_indeterminate(self):
        self.x['after']['memory.pressure']=None
        out=self.parse();self.assertEqual(out['status'],'INDETERMINATE_SYNTHETIC')
        self.assertIsNone(out['psi_stall_delta_microseconds_synthetic'])
        self.assertIn('after:memory.pressure',out['missing_observations'])
    def test_null_peak_indeterminate(self):
        self.x['after']['memory.peak']=None
        out=self.parse();self.assertEqual(out['status'],'INDETERMINATE_SYNTHETIC')
        self.assertIsNone(out['memory_peak_after_charged_bytes'])
    def test_mismatched_pressure_format(self):
        self.x['before']['memory.pressure']='some total=1\n';self.reject()
    def test_missing_full_pressure(self):
        self.x['before']['memory.pressure']=PERCENT.split('\nfull')[0];self.reject()
    def test_nonfinite_pressure(self):
        self.x['before']['memory.pressure']=PERCENT.replace('avg10=0.00','avg10=NaN');self.reject()
    def test_pressure_exponent(self):
        self.x['before']['memory.pressure']=PERCENT.replace('avg10=0.00','avg10=1e2');self.reject()
    def test_over100_pressure(self):
        self.x['before']['memory.pressure']=PERCENT.replace('avg10=0.00','avg10=101.00');self.reject()
    def test_duplicate_pressure_row(self):
        self.x['before']['memory.pressure']=PERCENT+PERCENT.splitlines()[0]+'\n';self.reject()
    def test_pressure_counter_rollback(self):
        self.x['after']['memory.pressure']=PERCENT.replace('total=100','total=10')
        out=self.parse();self.assertEqual(out['status'],'FLAGGED_SYNTHETIC')
        self.assertIn('PSI_COUNTER_ROLLBACK:some',out['flags'])
        self.assertIsNone(out['psi_stall_delta_microseconds_synthetic']['some'])
    def test_full_gt_some_pressure(self):
        self.x['after']['memory.pressure']=PERCENT.replace('total=20','total=900')
        self.assertIn('after:PSI_FULL_EXCEEDS_SOME',self.parse()['flags'])
    def test_full_delta_gt_some_delta(self):
        self.x['after']['memory.pressure']=PERCENT.replace('total=100','total=101').replace('total=20','total=31')
        self.assertIn('PSI_DELTA_FULL_EXCEEDS_SOME',self.parse()['flags'])
    def test_event_counter_rollback(self):
        self.x['before']['memory.events']=EVENTS.replace('high 0','high 7')
        out=self.parse();self.assertEqual(out['status'],'FLAGGED_SYNTHETIC')
        self.assertIsNone(out['memory_event_deltas_synthetic']['high'])
    def test_event_oom_kill(self):
        self.x['after']['memory.events']=EVENTS.replace('oom_kill 0','oom_kill 1')
        out=self.parse();self.assertIn('RESOURCE_EVENTS_NONZERO',out['flags'])
        self.assertEqual(out['memory_event_deltas_synthetic']['oom_kill'],1)
        self.assertEqual(out['qualification'],'NOT_QUALIFIED')
    def test_event_high(self):
        self.x['after']['memory.events']=EVENTS.replace('high 0','high 1')
        self.assertIn('RESOURCE_EVENTS_NONZERO',self.parse()['flags'])
    def test_event_missing_key(self):
        self.x['after']['memory.events']=EVENTS.replace('oom_kill 0\n','');self.reject()
    def test_event_duplicate_key(self):
        self.x['after']['memory.events']=EVENTS+'max 0\n';self.reject()
    def test_event_unknown_key(self):
        self.x['after']['memory.events']=EVENTS+'admin_verified 1\n';self.reject()
    def test_event_optional_key_change(self):
        self.x['after']['memory.events']=EVENTS+'oom_group_kill 0\n'
        self.assertIn('EVENT_KEYSET_CHANGED',self.parse()['flags'])
    def test_postcleanup_live_descendants_warning(self):
        self.x['after']['cgroup.events']='populated 1\nfrozen 0\n'
        self.assertIn('END_POPULATED_1_UNTRUSTED',self.parse()['flags'])
    def test_after_pids_nonzero_warning(self):
        self.x['after']['pids.current']='9\n'
        self.assertIn('END_PIDS_NONZERO_UNTRUSTED',self.parse()['flags'])
    def test_before_populated_nonzero_warning(self):
        self.x['before']['cgroup.events']='populated 1\nfrozen 0\n'
        self.assertIn('PRELAUNCH_POPULATED_NONZERO_UNTRUSTED',self.parse()['flags'])
    def test_populated_invalid(self):
        self.x['after']['cgroup.events']='populated 2\n';self.reject()
    def test_memory_peak_below_current(self):
        self.x['after']['memory.peak']='1\n'
        self.assertIn('after:PEAK_BELOW_CURRENT_NONATOMIC_OR_BAD_SAMPLE',self.parse()['flags'])
    def test_embedded_newline_in_integer(self):
        self.x['after']['memory.current']='1\n2\n';self.reject()
    def test_carriage_return(self):
        self.x['after']['memory.current']='0\r\n';self.reject()
    def test_nullbyte(self):
        self.x['after']['memory.current']='0\u0000';self.reject()
    def test_non_ascii_text(self):
        self.x['after']['memory.current']='１２３';self.reject()
    def test_extremely_long_raw_metric(self):
        self.x['after']['memory.current']='1'*4097;self.reject()
    def test_json_dictionary_not_list(self):
        with self.assertRaises(InvalidSyntheticInput):parse_bytes(b'[]')
    def test_no_metric_reading_from_filesystem(self):
        # No host collector hooks, and local fixture text remains untrusted.
        self.assertEqual(self.parse()['source_provenance'],'UNTRUSTED_SYNTHETIC')

if __name__=='__main__': unittest.main()

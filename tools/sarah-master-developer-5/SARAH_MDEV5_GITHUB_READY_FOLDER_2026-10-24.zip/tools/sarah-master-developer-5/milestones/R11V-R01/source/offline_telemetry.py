#!/usr/bin/env python3
"""Data-only cgroup-v2 telemetry analyzer for synthetic SARAH R11V test fixtures.

SECURITY BOUNDARY: accepts untrusted TEXT already supplied by the caller.
Does not read Linux kernel paths, create cgroups, launch workers, attest a host,
or qualify any sandbox. The result always has qualification=NOT_QUALIFIED.
"""
from decimal import Decimal, InvalidOperation
import json
import re

SCHEMA = 'SARAH_R11V_SYNTHETIC_CGROUP_TEXT_V1'
REPORT_SCHEMA = 'SARAH_R11V_OFFLINE_ANALYSIS_V1'
MAX_INPUT_BYTES = 128 * 1024
MAX_TEXT_FIELD_BYTES = 4096
MAX_INT = (1 << 63) - 1
TOP_KEYS = {'schema', 'provenance', 'claim', 'run_id', 'observer_label',
            'start_monotonic_ns', 'end_monotonic_ns', 'before', 'after'}
SNAPSHOT_KEYS = {'cgroup_identity_label', 'memory.current', 'memory.peak',
                 'memory.events', 'memory.pressure', 'cgroup.events', 'pids.current'}
EVENT_REQUIRED = {'high', 'max', 'oom', 'oom_kill'}
EVENT_ALLOWED = EVENT_REQUIRED | {'low', 'oom_group_kill'}
PRESSURE_LABELS = ('some', 'full')
DECIMAL_PERCENT = re.compile(r'(?:\d{1,3})(?:\.\d{1,2})?\Z', re.ASCII)
IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}\Z', re.ASCII)
UINT = re.compile(r'(?:0|[1-9][0-9]*)\Z', re.ASCII)

class InvalidSyntheticInput(ValueError):
    """A malformed or falsely privileged untrusted input."""

def _pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise InvalidSyntheticInput('duplicate JSON key')
        out[key] = value
    return out

def _reject_constant(_value):
    raise InvalidSyntheticInput('nonfinite JSON numeric constant')

def _strict_uint(value, name):
    if type(value) is not int or value < 0 or value > MAX_INT:
        raise InvalidSyntheticInput(name + ': nonnegative int64 required')
    return value

def _safe_uint_token(token, name):
    if not UINT.fullmatch(token) or len(token) > 19:
        raise InvalidSyntheticInput(name + ': malformed unsigned integer')
    return _strict_uint(int(token), name)

def _identifier(value, name):
    if type(value) is not str or not IDENTIFIER.fullmatch(value):
        raise InvalidSyntheticInput(name + ': invalid bounded opaque label')
    return value

def _text(value, name):
    if value is None:
        return None
    if type(value) is not str:
        raise InvalidSyntheticInput(name + ': expected string or null')
    try:
        raw = value.encode('ascii')
    except UnicodeEncodeError as exc:
        raise InvalidSyntheticInput(name + ': non-ASCII telemetry') from exc
    if not raw or len(raw) > MAX_TEXT_FIELD_BYTES or '\x00' in value or '\r' in value:
        raise InvalidSyntheticInput(name + ': missing, oversized or binary telemetry')
    return value

def _lines(value, name):
    # A single final newline is allowed; blank interior lines are not.
    if not value or '\r' in value:
        raise InvalidSyntheticInput(name + ': invalid lines')
    lines = value[:-1].split('\n') if value.endswith('\n') else value.split('\n')
    if not lines or any(not line for line in lines):
        raise InvalidSyntheticInput(name + ': empty lines')
    return lines

def _scalar(value, name):
    lines = _lines(value, name)
    if len(lines) != 1:
        raise InvalidSyntheticInput(name + ': expected one line')
    return _safe_uint_token(lines[0], name)

def _kv(value, name, allowed, required):
    out = {}
    for line in _lines(value, name):
        parts = line.split(' ')
        if len(parts) != 2 or not all(parts):
            raise InvalidSyntheticInput(name + ': malformed key/value line')
        k, v = parts
        if k not in allowed or k in out:
            raise InvalidSyntheticInput(name + ': unknown or duplicate key')
        out[k] = _safe_uint_token(v, name+'.'+k)
    if not required.issubset(out):
        raise InvalidSyntheticInput(name + ': missing required counters')
    return out

def _pressure(value, name):
    out = {}
    for line in _lines(value, name):
        tokens = line.split(' ')
        if len(tokens) != 5 or tokens[0] not in PRESSURE_LABELS or tokens[0] in out:
            raise InvalidSyntheticInput(name + ': pressure row structure')
        row = {}
        for expected, token in zip(('avg10', 'avg60', 'avg300', 'total'), tokens[1:]):
            head = expected+'='
            if not token.startswith(head):
                raise InvalidSyntheticInput(name + ': pressure key order')
            raw = token[len(head):]
            if expected == 'total':
                row[expected] = _safe_uint_token(raw, name+'.total')
            else:
                if not DECIMAL_PERCENT.fullmatch(raw):
                    raise InvalidSyntheticInput(name + ': invalid PSI percentage')
                try:
                    fraction = Decimal(raw)
                except InvalidOperation as exc:
                    raise InvalidSyntheticInput(name + ': invalid decimal') from exc
                if fraction > 100:
                    raise InvalidSyntheticInput(name + ': PSI percentage exceeds 100')
                row[expected] = str(fraction)
        out[tokens[0]] = row
    if set(out) != set(PRESSURE_LABELS):
        raise InvalidSyntheticInput(name + ': missing some/full rows')
    return out

def _snapshot(snapshot, stem):
    if type(snapshot) is not dict or set(snapshot) != SNAPSHOT_KEYS:
        raise InvalidSyntheticInput(stem + ': unexpected or missing snapshot fields')
    label = _identifier(snapshot['cgroup_identity_label'], stem+'.identity')
    parsers = {
        'memory.current': _scalar,
        'memory.peak': _scalar,
        'memory.events': lambda v, n: _kv(v, n, EVENT_ALLOWED, EVENT_REQUIRED),
        'memory.pressure': _pressure,
        'cgroup.events': lambda v, n: _kv(v, n, {'populated', 'frozen'}, {'populated'}),
        'pids.current': _scalar,
    }
    out = {'cgroup_identity_label': label}
    for k, parse in parsers.items():
        raw = _text(snapshot[k], stem+'.'+k)
        out[k] = None if raw is None else parse(raw, stem+'.'+k)
    if out['cgroup.events'] is not None:
        values = out['cgroup.events']
        if values['populated'] not in (0, 1) or ('frozen' in values and values['frozen'] not in (0, 1)):
            raise InvalidSyntheticInput(stem + ': invalid cgroup boolean value')
    return out

def analyze(item):
    if type(item) is not dict or set(item) != TOP_KEYS:
        raise InvalidSyntheticInput('unexpected or missing top-level fields')
    if (item['schema'] != SCHEMA or item['provenance'] != 'UNTRUSTED_SYNTHETIC'
        or item['claim'] != 'DEVELOPER_DEMONSTRATION_ONLY'):
        raise InvalidSyntheticInput('synthetic-only schema; privileged claims forbidden')
    run_id = _identifier(item['run_id'], 'run_id')
    observer = _identifier(item['observer_label'], 'observer_label')
    start = _strict_uint(item['start_monotonic_ns'], 'start')
    end = _strict_uint(item['end_monotonic_ns'], 'end')
    if start == 0 or end <= start:
        raise InvalidSyntheticInput('invalid synthetic observation interval')
    before = _snapshot(item['before'], 'before')
    after = _snapshot(item['after'], 'after')
    if before['cgroup_identity_label'] != after['cgroup_identity_label']:
        raise InvalidSyntheticInput('mismatched synthetic cgroup identity labels')

    gaps, flags = [], []
    for stage, snap in [('before', before), ('after', after)]:
        for name in SNAPSHOT_KEYS - {'cgroup_identity_label'}:
            if snap[name] is None:
                gaps.append(stage + ':' + name)
        if snap['memory.current'] is not None and snap['memory.peak'] is not None:
            if snap['memory.peak'] < snap['memory.current']:
                flags.append(stage + ':PEAK_BELOW_CURRENT_NONATOMIC_OR_BAD_SAMPLE')
        if snap['memory.pressure'] is not None:
            p = snap['memory.pressure']
            if p['full']['total'] > p['some']['total']:
                flags.append(stage + ':PSI_FULL_EXCEEDS_SOME')
    events_delta = None
    if before['memory.events'] is not None and after['memory.events'] is not None:
        e0, e1 = before['memory.events'], after['memory.events']
        if e0.keys() != e1.keys():
            flags.append('EVENT_KEYSET_CHANGED')
        events_delta = {}
        for k in sorted(e0.keys() & e1.keys()):
            if e1[k] < e0[k]:
                flags.append('EVENT_COUNTER_ROLLBACK:'+k)
                events_delta[k] = None
            else:
                events_delta[k] = e1[k] - e0[k]
        if any(events_delta.get(k, 0) for k in ('high', 'max', 'oom', 'oom_kill', 'oom_group_kill')):
            flags.append('RESOURCE_EVENTS_NONZERO')
    psi_delta = None
    if before['memory.pressure'] is not None and after['memory.pressure'] is not None:
        psi_delta = {}
        for level in PRESSURE_LABELS:
            v0 = before['memory.pressure'][level]['total']
            v1 = after['memory.pressure'][level]['total']
            if v1 < v0:
                flags.append('PSI_COUNTER_ROLLBACK:'+level)
                psi_delta[level] = None
            else:
                psi_delta[level] = v1-v0
        if psi_delta['full'] is not None and psi_delta['some'] is not None and psi_delta['full'] > psi_delta['some']:
            flags.append('PSI_DELTA_FULL_EXCEEDS_SOME')
    if after['cgroup.events'] is not None and after['cgroup.events']['populated'] != 0:
        flags.append('END_POPULATED_1_UNTRUSTED')
    if after['pids.current'] is not None and after['pids.current'] != 0:
        flags.append('END_PIDS_NONZERO_UNTRUSTED')
    if before['cgroup.events'] is not None and before['cgroup.events']['populated'] != 0:
        flags.append('PRELAUNCH_POPULATED_NONZERO_UNTRUSTED')
    # An unsigned, external, or qualified success verdict can NEVER be returned here.
    status = 'INDETERMINATE_SYNTHETIC' if gaps else ('FLAGGED_SYNTHETIC' if flags else 'CONSISTENT_SYNTHETIC')
    return {
        'schema': REPORT_SCHEMA,
        'run_id': run_id,
        'observer_label_untrusted': observer,
        'cgroup_identity_untrusted': before['cgroup_identity_label'],
        'source_provenance': 'UNTRUSTED_SYNTHETIC',
        'qualification': 'NOT_QUALIFIED',
        'auditor_verdict': 'NOT_PERFORMED',
        'status': status,
        'start_monotonic_ns_untrusted': start,
        'end_monotonic_ns_untrusted': end,
        'memory_current_before_charged_bytes': before['memory.current'],
        'memory_current_after_charged_bytes': after['memory.current'],
        'memory_peak_after_charged_bytes': after['memory.peak'],
        'memory_peak_measure': 'CGROUP_CHARGED_MEMORY_NOT_RSS',
        'peak_reset_or_fd_provenance_verified': False,
        'memory_event_deltas_synthetic': events_delta,
        'psi_stall_delta_microseconds_synthetic': psi_delta,
        'postcleanup_populated_untrusted': (after['cgroup.events'] or {}).get('populated'),
        'postcleanup_pids_untrusted': after['pids.current'],
        'missing_observations': sorted(gaps),
        'flags': sorted(flags),
        'kernel_containment_proven': False,
        'complete_descendant_cleanup_proven': False,
    }

def parse_bytes(data):
    if type(data) is not bytes or not data or len(data) > MAX_INPUT_BYTES:
        raise InvalidSyntheticInput('data must be nonempty bytes within 128 KiB')
    try:
        decoded = json.loads(data.decode('utf-8'), object_pairs_hook=_pairs, parse_constant=_reject_constant)
        return analyze(decoded)
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError, ValueError) as exc:
        if isinstance(exc, InvalidSyntheticInput):
            raise
        raise InvalidSyntheticInput('bad UTF-8, JSON, or numerical data') from exc

#!/usr/bin/env python3
"""Offline developer-only mutation probes; never independent qualification."""
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'source/offline_telemetry.py').read_text()
mutations={
  'M1_false_auditor_claim': ("'qualification': 'NOT_QUALIFIED'", "'qualification': 'AUDITOR_QUALIFIED'"),
  'M2_peak_mislabeled_rss': ("'memory_peak_measure': 'CGROUP_CHARGED_MEMORY_NOT_RSS'", "'memory_peak_measure': 'PROCESS_RSS'"),
  'M3_missing_observation_marked_consistent': ("status = 'INDETERMINATE_SYNTHETIC' if gaps else ('FLAGGED_SYNTHETIC' if flags else 'CONSISTENT_SYNTHETIC')", "status = 'CONSISTENT_SYNTHETIC'"),
  'M4_identity_mismatch_ignored': ("if before['cgroup_identity_label'] != after['cgroup_identity_label']:", "if False:"),
  'M5_psi_rollback_ignored': ("if v1 < v0:", "if False:"),
  'M6_populated_end_warning_disabled': ("if after['cgroup.events'] is not None and after['cgroup.events']['populated'] != 0:", "if False:"),
}
print('R11V OFFLINE DEVELOPER MUTATION CHALLENGES — not independent audit')
failures=[]
for name,(old,new) in mutations.items():
    if source.count(old)!=1:
        failures.append(name+': source delta match missing')
        continue
    with tempfile.TemporaryDirectory(prefix='r11v_mutation_') as tmp:
        dest=Path(tmp)
        (dest/'source').mkdir();(dest/'tests').mkdir()
        (dest/'source/offline_telemetry.py').write_text(source.replace(old,new))
        shutil.copy2(ROOT/'tests/test_offline_telemetry.py', dest/'tests/test_offline_telemetry.py')
        proc=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=dest,
                            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=10)
        seen = proc.returncode!=0 and ('FAIL' in proc.stdout or 'ERROR' in proc.stdout)
        print(name+': '+ ('KILLED' if seen else 'SURVIVED'))
        if not seen: failures.append(name)
print(f'Detected {len(mutations)-len(failures)}/{len(mutations)} deliberately unsafe source mutations')
if failures:
    print('WARNING: '+', '.join(failures))
    sys.exit(1)

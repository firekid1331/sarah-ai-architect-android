#!/usr/bin/env python3
"""Offline-only CLI for preexisting untrusted synthetic fixture files."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
from offline_telemetry import InvalidSyntheticInput, parse_bytes

def main(argv):
    if len(argv) != 2:
        print('usage: python tools/run_offline_analysis.py <synthetic-fixture.json>', file=sys.stderr)
        return 2
    try:
        # This reads *only* a path explicitly supplied by the user. It never
        # reads cgroupfs, spawns a process or treats path data as kernel evidence.
        path = Path(argv[1])
        if path.stat().st_size > 128*1024:
            raise InvalidSyntheticInput('fixture exceeds 128 KiB')
        report = parse_bytes(path.read_bytes())
    except (OSError, InvalidSyntheticInput) as exc:
        print('REJECTED_SYNTHETIC: '+str(exc), file=sys.stderr)
        return 1
    print(json.dumps(report, sort_keys=True, separators=(',', ':')))
    return 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv))

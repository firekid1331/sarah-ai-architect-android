# R11V-R01 offline synthetic telemetry contract

This contract governs **untrusted fixtures**. It neither designates a kernel observer nor establishes provenance.

## Input JSON

Top-level exact keys: `schema`, `provenance`, `claim`, `run_id`, `observer_label`, `start_monotonic_ns`, `end_monotonic_ns`, `before`, `after`.

- `schema` must equal `SARAH_R11V_SYNTHETIC_CGROUP_TEXT_V1`.
- `provenance` must equal `UNTRUSTED_SYNTHETIC`.
- `claim` must equal `DEVELOPER_DEMONSTRATION_ONLY`.
- All labels are length-bounded opaque identifiers; **they are not authenticated**.
- Timestamps are nonnegative bounded integers, and the ending value must be strictly later; **they are user-supplied and not attested**.
- Each snapshot contains the exact keys: `cgroup_identity_label`, `memory.current`, `memory.peak`, `memory.events`, `memory.pressure`, `cgroup.events`, `pids.current`. Each metric is **raw text** or `null`, not a filesystem path. The cgroup identity labels must match across snapshots.
- JSON has a 128-KiB bound; individual ASCII measurement fields have a 4096-byte bound. Duplicate JSON keys, `NaN`, `Infinity`, noncanonical integer spellings, duplicate or unknown counter keys, oversized values, booleans, and incompatible type coercions are rejected.

## Physical semantics and parser limitations

`memory.current` and `memory.peak` are **charged cgroup memory in bytes**, not peak RSS. `memory.peak` may depend on file-descriptor-specific reset semantics, and this synthetic parser **cannot establish** continuity of a kernel FD or measurement window. A peak less than current is flagged; it is not interpreted as a definitive violation because live snapshots can be non-atomic.

`memory.events` includes required `high`, `max`, `oom`, `oom_kill`, with optional `low` and `oom_group_kill`. Counters must be unbounded positive-text int64 values; counter rollback is flagged and the affected delta is `null`, never interpreted as a safe zero. Counter-keyset changes and positive `high/max/oom/oom_kill/oom_group_kill` deltas are flagged.

`memory.pressure` must contain exactly one `some` and one `full` line, each with `avg10`, `avg60`, `avg300`, `total` fields. The totals are cumulative **microseconds**; the averages are percentages over rolling intervals, not absolute peaks. Negative deltas are flagged and emitted as `null`; impossible relationships (for instance, `full > some`) are flagged as possible races/corruption and never used as security proof.

`cgroup.events:populated=0` and `pids.current=0` are merely *untrusted synthetic values*. They do not certify process-tree cleanup, and nonzero ending values generate flags. A memory-current value remaining above zero is not proof of living processes; charged caches may persist.

Missing (`null`) metrics lead to `INDETERMINATE_SYNTHETIC` and preserve explicit missing-observation names, never silently substituted zeroes. Malformed data is rejected with `InvalidSyntheticInput`.

## Output contract

`qualification` is **always** `NOT_QUALIFIED`; `auditor_verdict` is **always** `NOT_PERFORMED`; `kernel_containment_proven` and `complete_descendant_cleanup_proven` are **always false**. Results are only `CONSISTENT_SYNTHETIC`, `FLAGGED_SYNTHETIC`, or `INDETERMINATE_SYNTHETIC`. These are parsability/data-consistency assessments, not host safety decisions.

This component exposes **no action to run untrusted code or to change Linux containment**. Integrate only as a non-authoritative offline report producer until an independently governed protected observer exists. No release may treat this report as a signed host receipt.

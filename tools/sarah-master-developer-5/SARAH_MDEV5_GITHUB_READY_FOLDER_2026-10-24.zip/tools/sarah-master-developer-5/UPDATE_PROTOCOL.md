# SARAH Master Developer 5.0 — GitHub milestone process

1. Create a new `milestones/<MILESTONE-ID>/` snapshot for each substantive candidate; avoid silently overwriting frozen evidence.
2. Prefer branch + pull request for code changes; the owner decides what to merge.
3. Include source, tests, exact source hashes, reproduction commands, a candid developer report, and auditor handoff.
4. Update README/STATUS/MILESTONES/CHANGELOG and declare inherited tests, skips, failed tests, and unmet dependencies.
5. Never treat synthetic correctness, successful SHA validation, or self-review as independent host security qualification.
6. Keep full archival evidence (including original ZIPs, historical finding ledgers, and secrets) under authorized separate custody. This existing GitHub repository is PUBLIC.
7. Never publish credentials, tokens, private keys, personal information or actionable confidential vulnerability evidence.
8. Do not run software on devices, Minecraft, workers or production hosts without explicit authorization.
9. GitHub updates are performed when a real milestone is supplied and verified; no automatic background syncing is enabled by creating this folder.

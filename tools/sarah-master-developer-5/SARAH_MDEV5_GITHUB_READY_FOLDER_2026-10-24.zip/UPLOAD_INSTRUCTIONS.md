# GitHub handoff — SARAH Master Developer 5.0

Intended repository: `firekid1331/sarah-ai-architect-android` (public), branch `main` or a review branch.

Target path: `tools/sarah-master-developer-5/`.

The GitHub connector could read repository contents but its create-file operation returned **403 Resource not accessible by integration**. The folder is NOT yet created remotely. Update the GitHub app installation to grant repository **Contents: Read and write**, then ask ChatGPT to upload the prepared tree, or upload the extracted files with a Git client.

**Do not upload the ZIP itself as a single file if you intend GitHub to show a browsable folder.** Extract it and commit the nested `tools/sarah-master-developer-5` directory while preserving paths. Do not place the wrapper `SARAH_MASTER_DEVELOPER_5_GITHUB_READY` directory inside the repository.

This ZIP intentionally excludes sensitive historical ledgers and binary custody archives. Keep the full original R11V-R01 archive separately, SHA-256 listed in STATUS.md.
